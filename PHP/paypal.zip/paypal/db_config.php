<?php

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'paypal';
$db = mysqli_connect($host,$user,$password,$database);
if (!$db){trigger_error('Could not connect to MySQL: ' . mysqli_connect_error());}
?>